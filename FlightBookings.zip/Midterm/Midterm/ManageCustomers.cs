﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Midterm
{
    public partial class ManageCustomers : Form
    {
        private SqlConnection conn = new SqlConnection();
        private string constring = "Server=Deep\\SQLExpress; Database=NetClass; User=singbish; Password=Deepwalia826;";
        private SqlCommand cmd;

        public ManageCustomers()
        {
            InitializeComponent();
        }

        private void ManageCustomers_Load(object sender, EventArgs e)
        {
            refreshData();
        }
        private void handleEx(Exception ex1)
        {
            
            string message = ex1.Message.ToString();
            string caption = "error";
            MessageBox.Show(message, caption, MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
        }
        private void refreshData()
        {

            conn.ConnectionString = constring;
            cmd = conn.CreateCommand();
            try
            {
                string query = "select * from Customer;";
                cmd.CommandText = query;
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;
                cmbCustomer.DisplayMember = "Name";
                cmbCustomer.ValueMember = "customerID";
                cmbCustomer.DataSource = dt;

                reader.Close();

            }
            catch (Exception ex1)
            {
                handleEx(ex1);

            }
            finally
            {
                cmd.Dispose();
                conn.Close();
               
            }
        }

        private void addCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((tbName.Text == "") || (tbEmail.Text == "") || (tbAddress.Text == "") || (tbPhone.Text == ""))
            {
                MessageBox.Show("No textbox can be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
            string name = tbName.Text;
            string email = tbEmail.Text;
            string add = tbAddress.Text;
            string ph =tbPhone.Text;

            conn.ConnectionString = constring;
            cmd = conn.CreateCommand();
            try
            {
                string query = "INSERT INTO Customer VALUES('" + name + "','" + add + "','" + ph + "','" + email + "');";
                cmd.CommandText = query;
                conn.Open();
                cmd.ExecuteScalar();
                MessageBox.Show("Record Inserted ", "Congrats");


            }
            catch (Exception ee)
            {
                handleEx(ee);

            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                refreshData();

            }
        }

        private void updateCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int tbId = Convert.ToInt32(cmbCustomer.SelectedValue);
            string name = tbName.Text;
            string email = tbEmail.Text;
            string add = tbAddress.Text;
            string ph = tbPhone.Text;
            string query = "UPDATE Customer SET Name='" + name + "',Address='" + add + "',Phone='" + ph + "',Email='" + email
                + "' where customerID=" + tbId;
            conn.ConnectionString = constring;
            cmd = conn.CreateCommand();

            try
            {
                cmd.CommandText = query;
                conn.Open();
                cmd.ExecuteScalar();
                MessageBox.Show("Record Updated", "Success");

            }
            catch (Exception ee)
            {
                handleEx(ee);

            }
            finally
            {
                cmd.Dispose();
                conn.Close();

                refreshData();


            }

        }

        private void deleteCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int tbId = Convert.ToInt32(cmbCustomer.SelectedValue);
            conn.ConnectionString = constring;
            cmd = conn.CreateCommand();
            try
            {
                string query = "DELETE FROM Customer WHERE customerID=" + tbId;
                cmd.CommandText = query;
                conn.Open();
                cmd.ExecuteScalar();
                MessageBox.Show("Record Deleted", "Success");



            }
            catch (Exception ee)
            {
                handleEx(ee);

            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                refreshData();

            }

        }
    }
}
