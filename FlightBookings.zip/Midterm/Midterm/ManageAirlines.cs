﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Midterm
{
    public partial class ManageAirlines : Form
    {private SqlConnection conn = new SqlConnection();
           private string constring="Server=Deep\\SQLExpress; Database=NetClass; User=singbish; Password=Deepwalia826;";
          private SqlCommand cmd;
        public ManageAirlines()
        {
            InitializeComponent();
        }
        private void handleEx(Exception ex1)
        {
            string message = ex1.Message.ToString();
            string caption = "error";
            MessageBox.Show(message, caption, MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
        }
        private void refreshData()
        {

            conn.ConnectionString = constring;
            cmd = conn.CreateCommand();
            try
            {
                string query = "select * from Airlines;";
                cmd.CommandText = query;
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView2.DataSource = dt;
                cmbAirlines.DisplayMember = "Name";
                cmbAirlines.ValueMember = "airlineID";
                cmbAirlines.DataSource = dt;

                reader.Close();

            }
            catch (Exception ex1)
            {

                handleEx(ex1);
            }
            finally
            {
                cmd.Dispose();
                conn.Close();

            }
        }
        private void ManageAirlines_Load(object sender, EventArgs e)
        {
            cmbMeal.SelectedIndex = -1;
            refreshData();
        }

        private void btnAdd1_Click(object sender, EventArgs e)
        {
            
            if ((tbName1.Text == "") || (tbAirplane.Text == "") || (tbSA.Text == ""))
            {
                MessageBox.Show("No textbox can be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
            else
            {

                string name = tbName1.Text;
                string ap = tbAirplane.Text;
                string sa = tbSA.Text;
                string meal = cmbMeal.SelectedItem.ToString();
                conn.ConnectionString = constring;
                cmd = conn.CreateCommand();
                try
                {
                    string query = "INSERT INTO Airlines VALUES('" + name + "','" + ap + "','" + sa + "','" + meal + "');";
                    cmd.CommandText = query;
                    conn.Open();
                    cmd.ExecuteScalar();
                    MessageBox.Show("Record Inserted ", "Congrats");


                }
                catch (Exception ee)
                {
                    handleEx(ee);

                }
                finally
                {
                    cmd.Dispose();
                    conn.Close();
                    refreshData();

                }
            }
        }

        private void btnUpdate1_Click(object sender, EventArgs e)
        {
            int tbId = Convert.ToInt32(cmbAirlines.SelectedValue);
            string name = tbName1.Text;
            string ap = tbAirplane.Text;
            string sa = tbSA.Text;
            string meal = cmbMeal.SelectedItem.ToString();
            string query = "UPDATE Airlines SET Name='" + name + "',Airplane='" + ap + "',SeatsAvailable='" + sa + "',Meal='" +meal
                + "' where airlineID=" + tbId;
            conn.ConnectionString = constring;
            cmd = conn.CreateCommand();

            try
            {
                cmd.CommandText = query;
                conn.Open();
                cmd.ExecuteScalar();
                MessageBox.Show("Record Updated", "Success");

            }
            catch (Exception ee)
            {
                handleEx(ee);

            }
            finally
            {
                cmd.Dispose();
                conn.Close();

                refreshData();


            }
        }

        private void btnDelete1_Click(object sender, EventArgs e)
        {
            int tbId = Convert.ToInt32(cmbAirlines.SelectedValue);
            conn.ConnectionString = constring;
            cmd = conn.CreateCommand();
            try
            {
                string query = "DELETE FROM Airlines WHERE airlineID=" + tbId;
                cmd.CommandText = query;
                conn.Open();
                cmd.ExecuteScalar();
                MessageBox.Show("Record Deleted", "Success");



            }
            catch (Exception ee)
            {
                handleEx(ee);

            }
            finally
            {
                cmd.Dispose();
                conn.Close();
                refreshData();

            }
        }
    }
}
