﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'netClassDataSet.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.netClassDataSet.Customer);
            // TODO: This line of code loads data into the 'netClassDataSet.Airlines' table. You can move, or remove it, as needed.
            this.airlinesTableAdapter.Fill(this.netClassDataSet.Airlines);
            // TODO: This line of code loads data into the 'netClassDataSet.Flights' table. You can move, or remove it, as needed.
            this.flightsTableAdapter.Fill(this.netClassDataSet.Flights);

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
           var result= MessageBox.Show("Are u sure u want to exit?", "Caaution", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
           if (result == DialogResult.Yes)
           {
               Close();
           }
           
        }

        private void manageFlightsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageFlights mf = new ManageFlights();
            mf.Show();

        }

        private void manageAirlinesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageAirlines ma = new ManageAirlines();
            ma.Show();

        }

        private void manageCusomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageCustomers mc = new ManageCustomers();
            mc.Show();

        }
    }
}
