﻿namespace Midterm
{
    partial class ManageAirlines
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tbAirplane = new System.Windows.Forms.TextBox();
            this.tbSA = new System.Windows.Forms.TextBox();
            this.tbName1 = new System.Windows.Forms.TextBox();
            this.cmbAirlines = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbA = new System.Windows.Forms.Label();
            this.tbName3 = new System.Windows.Forms.Label();
            this.cmbMeal = new System.Windows.Forms.ComboBox();
            this.btnAdd1 = new System.Windows.Forms.Button();
            this.btnUpdate1 = new System.Windows.Forms.Button();
            this.btnDelete1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(53, 172);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(712, 262);
            this.dataGridView2.TabIndex = 19;
            // 
            // tbAirplane
            // 
            this.tbAirplane.Location = new System.Drawing.Point(133, 60);
            this.tbAirplane.Name = "tbAirplane";
            this.tbAirplane.Size = new System.Drawing.Size(326, 22);
            this.tbAirplane.TabIndex = 17;
            // 
            // tbSA
            // 
            this.tbSA.Location = new System.Drawing.Point(161, 89);
            this.tbSA.Name = "tbSA";
            this.tbSA.Size = new System.Drawing.Size(326, 22);
            this.tbSA.TabIndex = 16;
            // 
            // tbName1
            // 
            this.tbName1.Location = new System.Drawing.Point(133, 31);
            this.tbName1.Name = "tbName1";
            this.tbName1.Size = new System.Drawing.Size(326, 22);
            this.tbName1.TabIndex = 15;
            // 
            // cmbAirlines
            // 
            this.cmbAirlines.FormattingEnabled = true;
            this.cmbAirlines.Location = new System.Drawing.Point(543, 31);
            this.cmbAirlines.Name = "cmbAirlines";
            this.cmbAirlines.Size = new System.Drawing.Size(222, 24);
            this.cmbAirlines.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "Meal";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Seats Available";
            // 
            // tbA
            // 
            this.tbA.AutoSize = true;
            this.tbA.Location = new System.Drawing.Point(50, 60);
            this.tbA.Name = "tbA";
            this.tbA.Size = new System.Drawing.Size(70, 17);
            this.tbA.TabIndex = 11;
            this.tbA.Text = "AirPLANE";
            // 
            // tbName3
            // 
            this.tbName3.AutoSize = true;
            this.tbName3.Location = new System.Drawing.Point(50, 31);
            this.tbName3.Name = "tbName3";
            this.tbName3.Size = new System.Drawing.Size(45, 17);
            this.tbName3.TabIndex = 10;
            this.tbName3.Text = "Name";
            // 
            // cmbMeal
            // 
            this.cmbMeal.FormattingEnabled = true;
            this.cmbMeal.Items.AddRange(new object[] {
            "Fruits  ",
            "Chicken ",
            "Meat",
            "Fish"});
            this.cmbMeal.Location = new System.Drawing.Point(133, 118);
            this.cmbMeal.Name = "cmbMeal";
            this.cmbMeal.Size = new System.Drawing.Size(222, 24);
            this.cmbMeal.TabIndex = 20;
            // 
            // btnAdd1
            // 
            this.btnAdd1.Location = new System.Drawing.Point(543, 62);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(222, 23);
            this.btnAdd1.TabIndex = 21;
            this.btnAdd1.Text = "ADD";
            this.btnAdd1.UseVisualStyleBackColor = true;
            this.btnAdd1.Click += new System.EventHandler(this.btnAdd1_Click);
            // 
            // btnUpdate1
            // 
            this.btnUpdate1.Location = new System.Drawing.Point(543, 91);
            this.btnUpdate1.Name = "btnUpdate1";
            this.btnUpdate1.Size = new System.Drawing.Size(222, 23);
            this.btnUpdate1.TabIndex = 22;
            this.btnUpdate1.Text = "Update";
            this.btnUpdate1.UseVisualStyleBackColor = true;
            this.btnUpdate1.Click += new System.EventHandler(this.btnUpdate1_Click);
            // 
            // btnDelete1
            // 
            this.btnDelete1.Location = new System.Drawing.Point(543, 119);
            this.btnDelete1.Name = "btnDelete1";
            this.btnDelete1.Size = new System.Drawing.Size(222, 23);
            this.btnDelete1.TabIndex = 23;
            this.btnDelete1.Text = "Delete";
            this.btnDelete1.UseVisualStyleBackColor = true;
            this.btnDelete1.Click += new System.EventHandler(this.btnDelete1_Click);
            // 
            // ManageAirlines
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 465);
            this.Controls.Add(this.btnDelete1);
            this.Controls.Add(this.btnUpdate1);
            this.Controls.Add(this.btnAdd1);
            this.Controls.Add(this.cmbMeal);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.tbAirplane);
            this.Controls.Add(this.tbSA);
            this.Controls.Add(this.tbName1);
            this.Controls.Add(this.cmbAirlines);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbA);
            this.Controls.Add(this.tbName3);
            this.Name = "ManageAirlines";
            this.Text = "ManageAirlines";
            this.Load += new System.EventHandler(this.ManageAirlines_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox tbAirplane;
        private System.Windows.Forms.TextBox tbSA;
        private System.Windows.Forms.TextBox tbName1;
        private System.Windows.Forms.ComboBox cmbAirlines;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label tbA;
        private System.Windows.Forms.Label tbName3;
        private System.Windows.Forms.ComboBox cmbMeal;
        private System.Windows.Forms.Button btnAdd1;
        private System.Windows.Forms.Button btnUpdate1;
        private System.Windows.Forms.Button btnDelete1;
    }
}