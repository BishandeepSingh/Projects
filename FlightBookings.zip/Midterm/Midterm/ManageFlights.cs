﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm
{
    public partial class ManageFlights : Form
    {
        public ManageFlights()
        {
            InitializeComponent();
        }

        private void ManageFlights_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'netClassDataSet.Flights' table. You can move, or remove it, as needed.
            this.flightsTableAdapter.Fill(this.netClassDataSet.Flights);

        }

        private void btnAdd2_Click(object sender, EventArgs e)
        {
            if ((tbDPC.Text == "") || (tbDSC.Text == "") || (tbDD.Text == "") || (tbAD.Text == "")||(tbAirline.Text==""))
            {
                MessageBox.Show("No etxtbox can be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
            else
            {
                try
                {
                    DataSet1 ds1 = new DataSet1();
                    DataSet1TableAdapters.FlightsTableAdapter tatb2 = new DataSet1TableAdapters.FlightsTableAdapter();
                    DataSet1.FlightsRow fRow = ds1.Flights.NewFlightsRow();

                    fRow.Departure = tbDPC.Text;
                    fRow.Destination = tbDSC.Text;
                    fRow.departureDate = Convert.ToDateTime(tbDD.Text);
                    fRow.arrivalDate = Convert.ToDateTime(tbAD.Text);
                    fRow.airline = Convert.ToInt32(tbAirline.Text);
                    ds1.Flights.Rows.Add(fRow);
                    tatb2.Update(ds1.Flights);
                    tatb2.Fill(ds1.Flights);

                    dataGridView3.DataSource = ds1.Flights;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error in input");
                }
            }
        }
    }
}
