/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.A3.servlets;




public class CartItem {
   private int Code;
   private String Name;
   
   private float Price;
   private float Tax=0.0f;
   private int qtyOrdered;
   private float calculatedTax;
   //constructor
   public CartItem(){
       
   }
   public CartItem(int code,String name,float price,float tax,int qtyOrdered){
       this.Code=code;
       this.Name=name;
      
       this.Price=price;
       this.Tax=tax;
       this.qtyOrdered = qtyOrdered;
   }
   public int getCode(){
       return Code;
   }
   public String getName(){
       return Name;
   }
 
   public float getPrice(){
       return Price;
   }
   public float getTax(float t){
       if(Tax==0){
           return Tax =13;
       }
       else{
       return Tax =0.0f;
       
       }
   }
   public float getTax(){
       return Tax;
   }
   
    public float calculateTax(float tax,float price){
       if(tax==0){
            calculatedTax=0.0f;
        }
        else{
            calculatedTax=0.13f * price ;
        }
     
    
       return calculatedTax;
       
   }
   public int getQtyOrdered(){
       return qtyOrdered;
   }
   public void setQtyOrdered(int qtyOrdered){
       this.qtyOrdered=qtyOrdered;
   }

    

}

