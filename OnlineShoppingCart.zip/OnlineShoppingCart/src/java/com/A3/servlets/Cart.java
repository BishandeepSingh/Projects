/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.A3.servlets;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The Cart class models the shopping cart, which contains CartItem.
 * It also provides method to add() and remove() a CartItem.
 */

public class Cart {
    
    private List<CartItem> cart;//list of cart items
    
    //constructor
    
    public Cart(){
        cart = new ArrayList<CartItem>();
        
    }
    //add a CartItem into this cart
    public void add(int code,String name,float price,float tax,int qtyOrdered){
        // Check if the id is already in the shopping cart
        Iterator<CartItem>iter = cart.iterator();
        while(iter.hasNext()){
            CartItem item = iter.next();
            if(item.getCode()==code){
                //id found increase qtyOrderd
                item.setQtyOrdered(item.getQtyOrdered() + qtyOrdered); 
            }
        }
        //id not found .create a new cartitem
        cart.add(new CartItem( code, name, price, tax,qtyOrdered));
    }
    // Update the quantity for the given id
  public boolean update(int code,int newQty){
      Iterator<CartItem> iter = cart.iterator();
      while(iter.hasNext()){
          CartItem item = iter.next();
          if(item.getCode() == code){
               // id found, increase qtyOrdered
            item.setQtyOrdered(newQty);
            return true;
          }
          
      }
      return false;
  }
  
  //remove a CartItem given its id
  public void remove(int code)
  {
      Iterator<CartItem> iter = cart.iterator();
      while(iter.hasNext()){
          CartItem item = iter.next();
          if(item.getCode()==code){
              cart.remove(item);
              return;
          }
      }
  }
  // Get the number of CartItems in this Cart
   public int size() {
      return cart.size();
   }
 
   // Check if this Cart is empty
   public boolean isEmpty() {
      return size() == 0;
   }
  //Return all the CartItems in a List<CartItem>
   public List<CartItem> getItems() {
      return cart;
   }
 
   // Remove all the items in this Cart
   public void clear() {
      cart.clear();
   }

  }

