/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.A3.servlets;

import java.io.*;
import java.sql.*;
import java.util.logging.*;
import javax.naming.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.DataSource;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class EntryServlet extends HttpServlet {

    
        Connection con = null;
         Statement stmt; 
        
            
    protected void doGet(HttpServletRequest request,HttpServletResponse response)
            throws ServletException,IOException{
        response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
 
      Connection conn = null;
      Statement stmt = null;
      try {
         
            Class.forName("com.mysql.jdbc.Driver");
             conn= DriverManager.getConnection("jdbc:mysql://localhost/assignment3","root","lifeisgood1");
             stmt = (Statement)conn.createStatement();
           
             
         out.println("<html><head><title>welcome to Eshop</title></head><body>");
         out.println("<link rel=\"stylesheet\" href=\"Style.css\">");
         out.println("<div class=\"container\">");
         out.println("<div>");
         out.println("<h2>online cash register</h2></div>");
         out.println(" <div class=\"scan\">");
         
         out.println("<form method='get' action='QueryServlet'>");
         
         // A pull-down menu of all the authors with a no-selection option
         out.println("enter code to search: <input name='code'>");
         out.println("");//no selection
        /* while(rset.next())//list of all authors
         {
             String author = rset.getString("author");
             out.println("<option value='"+ code+"'>"+code+"</option>");
             
         }*/
         out.println("</input><br/>");
         
         out.println("<br /><br />");
         out.println("<input type='submit' value='SEARCH'/>");
         out.println("<input type='reset' value='CLEAR' />");
         out.println("</form>");
                  out.println("</div>");

         out.println("</div>");
                 
         
         // Show "View Shopping Cart" if the cart is not empty
         HttpSession session = request.getSession(false);//check if session exists
        
        out.println("</body></html>"); 
             
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(EntryServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
       finally {
         out.close();
         try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();  // Return the connection to the pool
         } catch (SQLException ex) {
            Logger.getLogger(EntryServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    }

    @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
      doGet(request, response);
   }
    

}
