/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.A3.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.sql.*;
import java.util.logging.*;
import javax.naming.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.DataSource;
public class CartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        //retrieve current httpsession object.if none,create one
        HttpSession session = request.getSession();
        Cart cart;
        synchronized (session){
            // synchronized to prevent concurrent updates
         // Retrieve the shopping cart for this session, if any. Otherwise, create one.
            
            cart  = (Cart) session.getAttribute("cart");
            if(cart == null){ //no cart create one
                cart = new Cart();
                session.setAttribute("cart",cart); //save it into session
                
                
            }
        }
        Connection conn=null;
        Statement stmt = null;
        ResultSet rset = null;
        String sqlStr = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
             conn= DriverManager.getConnection("jdbc:mysql://localhost/assignment3","root","lifeisgood1");
             stmt = (Statement)conn.createStatement();
              
             out.println("<html><head><title>Shopping Cart</title></head><body>");
         
 
        
         
         String todo = request.getParameter("todo");
         if(todo == null) todo= "view"; // to prevent null pointer
         
         if(todo.equals("add") || todo.equals("update")){
           
             
             String[] codes = request.getParameterValues("code");
             if(codes == null){
                 out.println("<h3>please enter code to search! or select value</h3></body></html>");
                 return;
                 
             }
             for(String Code :codes){
                 sqlStr = "SELECT * FROM productcatalogue WHERE code = " +Code;
                 //System.out.println(sqlStr);//for debugging
                 rset = stmt.executeQuery(sqlStr);
                 rset.next();//expect only one row in resultset
                 int code = rset.getInt("code");
                 String name = rset.getString("name"); 
                 float price = rset.getFloat("price");
                 int tax = rset.getInt("taxable");
                 
                 
                 //get quantity ordered -- no error check
                 
                 int qtyOrdered = Integer.parseInt(request.getParameter("qty" +code));
                 
                 switch (todo) {
                     case "add":
                         cart.add(code,name,price,tax,qtyOrdered);
                         break;
                     case "update":
                         cart.update(code, qtyOrdered);
                         break;
                     case "remove":
                             cart.remove(code);
                             break;
                 }
             }
             
         }
         else if(todo.equals("remove")){
             String id = request.getParameter("id");//only one id for remove case
             cart.remove(Integer.parseInt(id));
             
         }
         
         //all cases - always display the shopping cart
         if(cart.isEmpty()){
             out.println("<p>your shopping cart is empty");
         }
         else{
              out.println("<link rel=\"stylesheet\" href=\"Style.css\">");
         out.println("<div class=\"container\">");
        out.println("<h2> Your Shopping Cart</h2>");
             out.println("<table border='1' cellpadding='6'>");
            out.println("<tr>");
            out.println("<th>name</th>");
            out.println("<th>price</th>");
            out.println("<th>tax</th>");
            out.println("<th>QTY</th>");
            out.println("<th>REMOVE</th></tr>");
            
            float totalPrice = 0f;
            for(CartItem item : cart.getItems()){
                int code = item.getCode();
                String name = item.getName();
                
                float price = item.getPrice();
                float tax = item.getTax();
                int qtyOrdered = item.getQtyOrdered();
                float cTax  = item.calculateTax(tax, price);
                out.println("<tr>");
                 
                out.println("<td>" + name+ "</td>");
                out.println("<td>"+ price+"</td>");
                 
                out.println("<td>"+cTax+"</td>");
                
                out.println("<td><form method='get'>");
                out.println("<input type='hidden' name='todo' value='update' />");
                out.println("<input type='hidden' name='code' value='"+ code+"'/>" );
              out.println("<input type='text' size='3' name='qty"
                       + code + "' value='" + qtyOrdered + "' />" );
               out.println("<input type='submit' name='todo' value='Update' />");
               out.println("</form></td>");
 
               out.println("<td><form method='get'>");
               
               out.println("<input type='hidden' name='todo"  + code + "' value='remove' />");
               //out.println("<input type='hidden' name='code' value='" + code + "'>");
               out.println("<input type='submit' value='Remove'>");
               out.println("</form></td>");
               out.println("</tr>");
               totalPrice += (price * qtyOrdered) +cTax;
 
            }
            out.println("<tr><td colspan='5' align='right'>Total Money: $");
            out.printf("%.2f</td></tr>", totalPrice);
            out.println("</table>");
         }
        out.println("<p><a href='EntryServlet'>Select More items...</a></p>");
         
         
         out.println("</body></html>");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(EntryServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally {
         out.close();
         try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();  // return the connection to the pool
         } catch (SQLException ex) {
            Logger.getLogger(CartServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
        
    }
    }
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    

}
