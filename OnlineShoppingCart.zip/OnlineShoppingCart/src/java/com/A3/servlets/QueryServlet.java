/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.A3.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.sql.*;
import java.util.logging.*;
import javax.naming.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.*;
 

public class QueryServlet extends HttpServlet {

    Cart cart ;
    CartItem item = new CartItem();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
    
      Connection conn = null;
      Statement stmt = null;
       try {
            
            
             // Retrieve and process request parameters: "author" and "search"
             String code = request.getParameter("code");
             boolean hasAuthorParam = code !=null;
            
             
             out.println("<html><head><title>Query Results</title></head></html>");
             
             
             if(!hasAuthorParam){
                 out.println("<h3>please select an author or enter an search item</h3>");
                 out.println("<p><a href='EntryServlet'>back to select</a></p>");
                 
             }
             else{
                 Class.forName("com.mysql.jdbc.Driver");
             conn= DriverManager.getConnection("jdbc:mysql://localhost/assignment3","root","lifeisgood1");
             stmt = (Statement)conn.createStatement();
             
             // Form a SQL command based on the param(s) present
            StringBuilder sqlStr = new StringBuilder(); 
            
            if (hasAuthorParam) {
               sqlStr.append("SELECT * FROM productcatalogue WHERE code=" +code);
            }
            
           
            //System.out.println(sqlStr);  // for debugging
            ResultSet rset = stmt.executeQuery(sqlStr.toString());
            
            if(!rset.next()){//check for empty result set(not book found)
                out.println("<h3>no record found.please try again</h3>");
                out.println("<p><a href='EntryServlet'>back to select</a></p>");
                
            }
            else{
                 // Print the result in an HTML form inside a table
                 out.println("<link rel=\"stylesheet\" href=\"Style.css\">");
         out.println("<div class=\"container\">");
         out.println("<h2>items scanned</h2>");
                out.println("<form method='get' action='CartServlet'>");
                out.println("<input  type='hidden' name='todo' value='add' />");
                out.println("<table border='1' cellpadding='6'>");
                out.println("<tr>");
                out.println("<th>&nbsp;</th>");
                out.println("<th>code</th>");
                
                out.println("<th>name</th>");
                out.println("<th>PRICE</th>");
                out.println("<th>Tax</th>");
                out.println("<th>QTY</th>");
                out.println("</tr>");
                
                // ResultSet's cursor now pointing at first row
               do {
                  new Cart();
                   
                   float tax = rset.getFloat("taxable");
                  float calTax = item.getTax(tax);
                  code = rset.getString("code");
                  out.println("<tr>");
                  out.println("<td><input type='checkbox' name='code' value='" + code + "' /></td>");
                  out.println("<td>"+ rset.getString("code")+"</td>");
                  out.println("<td>" + rset.getString("name") + "</td>");
                  out.println("<td>" + rset.getString("price") + "</td>");
                  out.println("<td>" + calTax + "%</td>");
                  out.println("<td><input type='text' size='1' value='1' name='qty" + code + "' /></td>");
                  out.println("</tr>");
               } while (rset.next());
               out.println("</table><br />");
 
               // Submit and reset buttons
               out.println("<input type='submit' value='Add to My Shopping Cart' />");
               out.println("<input type='reset' value='CLEAR' /></form>");
 
               // Hyperlink to go back to search menu
               out.println("<p><a href='CartServlet'>Back to Select Menu</a></p>");
 out.println("</div>");
               // Show "View Shopping Cart" if cart is not empty
               HttpSession session = request.getSession(false);//check if session exists
               if(session !=null){
                   
                   synchronized (session){
                       // Retrieve the shopping cart for this session, if any. Otherwise, create one.
                       cart = (Cart) session.getAttribute("cart");
                       if(cart !=null && !cart.isEmpty()){
                           out.println("<p><a href='CartServlet?todo=view'>view shopping cart</a></p>");
                       }
                   }
               }
               out.println("</body></html>");
               
                
            }
            
             }
             
             
        
         
             
        } catch (ClassNotFoundException | SQLException ex) {
            out.println("<h3>Service not available. Please try again later!</h3></body></html>");
            Logger.getLogger(EntryServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
       finally {
         out.close();
         try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();  // Return the connection to the pool
         } catch (SQLException ex) {
            Logger.getLogger(QueryServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
       }
    
        
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
}
    
}
