

package servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class vieworders extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
              PrintWriter out = response.getWriter();  
        ResultSet rs=null;   
        Connection conn=null;
        PreparedStatement ps=null;
             try{
         Class.forName("com.mysql.jdbc.Driver");
        conn= DriverManager.getConnection("jdbc:mysql://localhost/pizzasystem","root","");
        String query = "SELECT * FROM orderinfo";
        ps = conn.prepareStatement(query);  
        rs = ps.executeQuery();
        out.println("<html><head><title>View Orders</title></head><body><table border='1'>");
        out.println("<th>Delivery</th><th>Size</th><th>Toppings</th><th>Quantity</th><th>Price</th>"); 
        while (rs.next()) {
        out.println("<tr><td>"+rs.getBoolean("Delivery")+"</td><td>"+rs.getString("SizeOfPizza")); 
        out.println("</td><td>"+rs.getInt("NumOfToppings")+"</td><td>"+rs.getInt("Quantity")+"</td><td>"+"$"+rs.getDouble("Price")+"</td></tr>");
             }
        out.println("</table></body></html>");
            }
             catch (Exception ex) {
           System.err.println("error");
        }
    }


}
