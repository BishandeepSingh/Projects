
package servlets;


import bussiness.price;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Arrays;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class orderinfo extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    
  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {          
         String type=request.getParameter("delivery");
        Boolean delivery=Boolean.parseBoolean(type);
        String Size=request.getParameter("size");
        int quantity=Integer.parseInt(request.getParameter("quantity"));
        String[] toppings=request.getParameterValues("toppings");
        int notoppings = toppings.length;
        price p=new price();
        double price=p.getPrice(notoppings,Size,quantity);
       try{
          Connection conn=null;
         PreparedStatement stmt;
         String query;
         Class.forName("com.mysql.jdbc.Driver");
        conn=DriverManager.getConnection("jdbc:mysql://localhost/pizzasystem","root","");
        query="INSERT INTO orderinfo(Delivery,SizeOfPizza,NumOfToppings,Quantity,Price) VALUES(?, ?, ?, ?, ?)";
           stmt=conn.prepareStatement(query);
            stmt.setString(2,Size);
            stmt.setInt(3,notoppings);
            stmt.setInt(4,quantity);
            stmt.setBoolean(1,delivery);
            stmt.setDouble(5,price);
            stmt.executeUpdate();
         }
             catch (Exception e) {
                 System.err.println();
            }
           request.setAttribute("Total",quantity);
           request.setAttribute("delivery", delivery);
           request.setAttribute("Size",Size);
           request.setAttribute("notoppings",notoppings);
           request.setAttribute("quantity",quantity);
           RequestDispatcher r = request.getRequestDispatcher("receipt.jsp");
           r.forward(request, response);
        }
       
    }

    

