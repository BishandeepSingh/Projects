
package servlets;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class getUser extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
      
    }

   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String firstname=request.getParameter("fname");
       String lastname=request.getParameter("lname");
       String phno=request.getParameter("num");
       String add=request.getParameter("add");
       request.setAttribute("fname", firstname);
       RequestDispatcher r=request.getRequestDispatcher("enterorder.jsp");
               r.forward(request, response);
    }

   

}
