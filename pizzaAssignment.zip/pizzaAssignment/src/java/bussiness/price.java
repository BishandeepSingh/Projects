
package bussiness;
public class price {
    int quantity;
    String Size;
    double price;
    int notoppings;
    int sizeprice;
  
   public double getPrice(int nooftoppings,String Size,int quantity){
       if("small".equals(Size)){
           sizeprice=5;}
       else{
           sizeprice=7;
       } price =quantity*(sizeprice+nooftoppings);
       return price;
   }           
}

