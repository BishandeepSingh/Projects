/*
 * A User JavaBean
 */

package com.sheridanbank.business;

import java.io.Serializable;

/**
 *
 * @author Justin
 */
public class Account {
    private int accId;

    public int getAccId() {
        return accId;
    }

    public void setAccId(int accId) {
        this.accId = accId;
    }

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

 

    public String getBal() {
        return bal;
    }

    public void setBal(String bal) {
        this.bal = bal;
    }
    private String accNo;
    private String type;
    private User user;
    private String bal;
   
    
    public Account() {
        accId = 0;
        accNo= "";
        type = "";
        user = null;
        bal = "";
      
    }
    
   
    
    public Account(int accId, String accNo, String type,User userId, String bal) {
        this.accId = accId;
        this.accNo = accNo;
        this.type = type;
        this.user = userId;
        this.bal = bal;
       
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the userId
     */
    
}
