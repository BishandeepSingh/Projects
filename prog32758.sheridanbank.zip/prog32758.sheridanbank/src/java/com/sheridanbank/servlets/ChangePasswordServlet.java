/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sheridanbank.servlets;

import com.sheridanbank.business.User;
import com.sheridanbank.dao.UserDAO;
import com.sheridanbank.db.DBConnection;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Arun
 */
public class ChangePasswordServlet extends HttpServlet {
   
    /** 
     * Handles the HTTP <code>GET</code> method. Delete if not used.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
       
    } 

    /** 
     * Handles the HTTP <code>POST</code> method. Delete if not used.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
                // TODO: Get the username from the request
        
        String strCurPasswd = request.getParameter("curPass");
        String strNewPasswd = request.getParameter("newPass");
        
        // TODO: Get the DBConnection object stored in the ServletContext for 
        // use by the DAO classes
        DBConnection dbConn = (DBConnection)request.getServletContext().getAttribute("dbConn");        
       
        User user = (User)request.getSession().getAttribute("user");
        String strResult= "";
        
         //Validate the current password with the user entered data in the form
        if(user.getPassword().equals(strCurPasswd))
        {
            //Check if current Password and new Password entered in the form are the same
            if(strCurPasswd.equals(strNewPasswd))
            {
                strResult = "UPDATE not done. Current password same as New password";
            }
            else
            {
               UserDAO userDAO = new UserDAO();
                boolean result = userDAO.changePassword
                (dbConn.getConnection(),user.getUserId(), strNewPasswd); 
                if(result)
                {
                    strResult = "PASSWORD HAS BEEN CHANGED";
                    user.setPassword(strNewPasswd);
                }
                else
                {
                    strResult = "CANNOT CHANGE PASSWORD. UPDATE UNSUCCESSFUL";
                }                
            }
        }          
        // TODO: Store the User object returned in the session
        request.getSession().setAttribute("user", user);  
        
        //Set result as an attribute
        request.setAttribute("result", strResult);
        
        // TODO: Forward the request to user_main.jsp
        RequestDispatcher view = request.getRequestDispatcher(response.encodeURL("passwordUpdated.jsp"));
        view.forward(request, response);

    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
