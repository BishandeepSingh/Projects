/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sheridanbank.dao;

import com.sheridanbank.business.Account;
import com.sheridanbank.business.User;
import com.sheridanbank.db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Bishan
 */
public class AccountDao {
    
    public ArrayList<Account> getAllAccounts(Connection conn) {
        Account account = null;
        ArrayList<Account> accountList = new ArrayList();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM account";

            ps = conn.prepareStatement(sql);
            

            rs = ps.executeQuery();

            while (rs.next()) {
                // Get the user info
             
                int accId = rs.getInt("AccountId");
                String accNo = rs.getString("AccountNumber");
                String type = rs.getString("AccountType");
                int userId = rs.getInt("UserId");
                 String bal = rs.getString("Balance");
                 
                 UserDAO userDAO = new UserDAO();
                
                User user = userDAO.getUserById(conn,userId);
                String firstname=rs.getString("firstname");
                  String lastname=rs.getString("lastname");
                
                // Initialize the user return variable
                account = new Account(accId, accNo, type, user, bal);
                accountList.add(account);
            }
            return accountList;

        } catch (SQLException e) {
            System.err.println("SQLException: " + e.getMessage());
            return null;
        } finally {
            DBConnection.closeJDBCObjects(conn, ps, rs);
            
        }
    }
    public ArrayList<Account> getAccountByUserId(Connection conn,int userId){
      Account acct=null;
      PreparedStatement ps=null;
      ResultSet rs=null;
      ArrayList<Account> list=new ArrayList();
      try{
          String sql="SELECT * FROM account where userId = ?";
          ps=conn.prepareStatement(sql);
      
          ps.setInt(1, userId);
          rs=ps.executeQuery();
          while(rs.next()){
             int accNo=rs.getString("AcccountId");
             
          }
          
          
      }catch(Exception e){
          
      }
      
      
    }

    
}
