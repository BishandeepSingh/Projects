/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sheridanbank.dao;

import java.sql.*;
import com.sheridanbank.business.User;
import com.sheridanbank.db.DBConnection;
import java.util.ArrayList;

/**
 *
 * @author Justin
 */
public class UserDAO {

    public User getUser(Connection conn, String username) {
        User user = null;

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM User WHERE Username = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1, username);

            rs = ps.executeQuery();

            while (rs.next()) {
                // Get the user info
                int userId = rs.getInt("UserId");
                String password = rs.getString("Password");
                String role = rs.getString("Role");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");

                // Initialize the user return variable
                user = new User(userId, username, password, role, firstName, lastName);
            }

        } catch (SQLException e) {
            System.err.println("SQLException: " + e.getMessage());
        } finally {
            DBConnection.closeJDBCObjects(conn, ps, rs);
            return user;
        }
    }
    
     public User getUserById(Connection conn, int userid) {
        User user = null;

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM User WHERE UserId = ?";

            ps = conn.prepareStatement(sql);
            ps.setInt(1, userid);

            rs = ps.executeQuery();

            while (rs.next()) {
                // Get the user info
              String username = rs.getString("Username");
                String password = rs.getString("Password");
                String role = rs.getString("Role");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");

                // Initialize the user return variable
                user = new User(userid, username, password, role, firstName, lastName);
            }

        } catch (SQLException e) {
            System.err.println("SQLException: " + e.getMessage());
        } finally {
            DBConnection.closeJDBCObjects(conn, ps, rs);
            return user;
        }
    }
    public ArrayList<User> getAllUser(Connection conn) {
        User user = null;
        ArrayList<User> userList = new ArrayList();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM User";

            ps = conn.prepareStatement(sql);
            

            rs = ps.executeQuery();

            while (rs.next()) {
                // Get the user info
                String username = rs.getString("Username");
                int userId = rs.getInt("UserId");
                String password = rs.getString("Password");
                String role = rs.getString("Role");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                
                // Initialize the user return variable
                user = new User(userId, username, password, role, firstName, lastName);
                userList.add(user);
            }
            return userList;

        } catch (SQLException e) {
            System.err.println("SQLException: " + e.getMessage());
            return null;
        } finally {
            DBConnection.closeJDBCObjects(conn, ps, rs);
            
        }
    }

    public boolean changePassword(Connection conn, int userId, String newPassword) {
        boolean result = false;

        // Declare JDBC objects
        PreparedStatement ps = null;

        try {
            String sql = "Update User set Password = ? where userId = ? ";

            ps = conn.prepareStatement(sql);
            ps.setInt(2, userId);
            ps.setString(1, newPassword);

            int count = ps.executeUpdate();

            if (count > 0) {
                result = true;
            }

        } catch (SQLException e) {
            System.err.println("SQLException: " + e.getMessage());
        } finally {
            DBConnection.closeJDBCObjects(conn, ps);

            return result;
        }
    }

    public boolean addUser(Connection conn, User user) {
        boolean success = false;

        // Declare JDBC objects
        PreparedStatement ps = null;

        try {
            String sql = "INSERT INTO User(Username, Password, Role, "
                    + " FirstName, LastName) VALUES(?, ?, ?, ?, ?);";

            ps = conn.prepareStatement(sql);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getRole());
            ps.setString(4, user.getFirstName());
            ps.setString(5, user.getLastName());

            int count = ps.executeUpdate();

            if (count > 0) {
                success = true;
            }

        } catch (SQLException e) {
            System.err.println("SQLException: " + e.getMessage());
        } finally {
            DBConnection.closeJDBCObjects(conn, ps);
            return success;
        }
    }
}
